interface Sorter {
    public int[] sort(int[] arr);
}
